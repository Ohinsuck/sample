using UnityEngine;
using TMPro;

public class ComboBoxCtrl : MonoBehaviour
{
    public TMP_Text comboText;

    public void ShowCombo(int combo)
    {
        comboText.text = combo.ToString();
        // 필요시 애니메이션 코드 추가 가능
    }
}