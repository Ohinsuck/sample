using UnityEngine;

public class NoteBehavior : MonoBehaviour
{
    public float targetTime, fallSpeed = 5.0f, duration = 0f;
    public bool isLongNote = false;
    public int laneNumber = 0;
    private float missThresholdY = -10f;

    public void Initialize(float target, int lane, bool isLong, float d)
    {
        targetTime = target;
        laneNumber = lane;
        isLongNote = isLong;
        duration = d;
    }

    void Update()
    {
        float t = targetTime - Time.time;
        transform.position = new Vector3(transform.position.x, t * fallSpeed, transform.position.z);
        if (transform.position.y < missThresholdY) Destroy(gameObject);
    }
}
